import 'package:cloud_firestore/cloud_firestore.dart';
import '../schema/bus_record.dart';
import '../schema/booking_record.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Set this to true to use real Firestore, false for mock data
  static bool useRealFirestore = false;

  Future<List<BusRecord>> fetchBuses(String from, String to) async {
    if (!useRealFirestore) {
      // Return Mock Data
      await Future.delayed(Duration(seconds: 1)); // Simulate network lag
      return [
        BusRecord.fromMap({
          'name': 'Deshmukh Premium AC',
          'type': 'Volvo Multi-Axle AC',
          'price': 850.0,
          'departureCity': from,
          'arrivalCity': to,
          'depTime': '08:30 AM',
          'arrTime': '12:45 PM',
          'rating': '4.8',
          'seatsAvailable': '12'
        }, 'bus1'),
        BusRecord.fromMap({
          'name': 'Shivneri Express',
          'type': 'Scania Luxury AC',
          'price': 720.0,
          'departureCity': from,
          'arrivalCity': to,
          'depTime': '10:15 AM',
          'arrTime': '02:00 PM',
          'rating': '4.5',
          'seatsAvailable': '4'
        }, 'bus2'),
        BusRecord.fromMap({
          'name': 'Nightlink Sleeper',
          'type': 'Electric Sleeper AC',
          'price': 1200.0,
          'departureCity': from,
          'arrivalCity': to,
          'depTime': '10:00 PM',
          'arrTime': '06:30 AM',
          'rating': '4.9',
          'seatsAvailable': '8'
        }, 'bus3'),
      ];
    }

    try {
      final snapshot = await _db.collection('buses')
          .where('departureCity', isEqualTo: from)
          .where('arrivalCity', isEqualTo: to)
          .get();

      return snapshot.docs.map((doc) => BusRecord.fromFirestore(doc)).toList();
    } catch (e) {
      print('Error fetching buses: $e');
      return [];
    }
  }

  Future<List<BookingRecord>> fetchUserBookings(String userId) async {
    if (!useRealFirestore) {
      await Future.delayed(Duration(seconds: 1));
      return [
        BookingRecord(
          id: 'b1',
          userId: userId,
          busId: 'bus1',
          busName: 'Deshmukh Premium AC',
          busType: 'AC • Sleeper',
          departureCity: 'Mumbai',
          arrivalCity: 'Pune',
          depTime: '08:30 PM',
          arrTime: '06:00 AM',
          seatNumbers: ['S-12', 'S-13'],
          passengers: [],
          totalAmount: 1250.0,
          status: 'upcoming',
          timestamp: DateTime.now().add(Duration(days: 2)),
        ),
      ];
    }

    try {
      final snapshot = await _db.collection('bookings')
          .where('userId', isEqualTo: userId)
          .orderBy('timestamp', descending: true)
          .get();

      return snapshot.docs.map((doc) => BookingRecord.fromFirestore(doc)).toList();
    } catch (e) {
      print('Error fetching bookings: $e');
      return [];
    }
  }

  Future<String?> createBooking(BookingRecord booking) async {
    if (!useRealFirestore) {
      print('MOCK: Saving booking to Firestore: ${booking.toMap()}');
      return 'mock_booking_id';
    }

    try {
      final docRef = await _db.collection('bookings').add(booking.toMap());
      return docRef.id;
    } catch (e) {
      print('Error creating booking: $e');
      return null;
    }
  }
}
