import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/components/app_nav_bar.dart';
import '/components/app_header.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '../widgets/islamic_card.dart';

class HajjDashboardScreen extends ConsumerWidget {
  static const String routeName = 'HajjDashboard';
  const HajjDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      bottomNavigationBar: const AppNavBar(currentRoute: HajjDashboardScreen.routeName),
      body: Column(
        children: [
          AppHeader(
            title: 'Hajj & Umrah',
            showBackButton: true,
            actionWidget: IconButton(
              icon: Icon(Icons.notifications_none, color: FlutterFlowTheme.of(context).primaryText),
              onPressed: () {},
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Upcoming Journey Card
                  IslamicCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(Icons.flight_takeoff_rounded, color: Colors.white, size: 20),
                            ),
                            const SizedBox(width: 12),
                            const Text(
                              'Your Upcoming Journey',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'Hajj Premium Package 2026',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            height: 1.2,
                          ),
                        ),
                        const SizedBox(height: 24),
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _buildInfoItem('Departure', '15 Jun 2026'),
                              _buildInfoItem('Duration', '21 Days'),
                              _buildInfoItem('Status', 'Visa Pending', isStatus: true),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Quick Actions Section Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Quick Actions',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            letterSpacing: -0.5,
                            color: FlutterFlowTheme.of(context).primaryText),
                      ),
                      TextButton(
                        onPressed: () => context.pushNamed('HajjPackages'),
                        child: Text('See All', style: TextStyle(color: FlutterFlowTheme.of(context).primary)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 4,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    children: [
                      _buildQuickAction(context, Icons.card_travel_rounded, 'Packages', const Color(0xFFD4AF37), () {
                        context.pushNamed('HajjPackages');
                      }),
                      _buildQuickAction(context, Icons.access_time_filled_rounded, 'Prayers', const Color(0xFF06402B), () {
                        context.pushNamed('IslamicTools');
                      }),
                      _buildQuickAction(context, Icons.menu_book_rounded, 'Duas', const Color(0xFF06402B), () {
                        context.pushNamed('IslamicTools');
                      }),
                      _buildQuickAction(context, Icons.explore_rounded, 'Qibla', const Color(0xFF06402B), () {
                        context.pushNamed('IslamicTools');
                      }),
                    ],
                  ),
                  const SizedBox(height: 32),

                  // Journey Progress Section
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Preparation Status',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            letterSpacing: -0.5,
                            color: FlutterFlowTheme.of(context).primaryText),
                      ),
                      TextButton(
                        onPressed: () => context.pushNamed('MyJourney'),
                        child: Text('See All', style: TextStyle(color: FlutterFlowTheme.of(context).primary)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Container(
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.03),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        children: [
                          _buildStep(context, Icons.check_circle_rounded, 'Package Selected', 'Premium Hajj 2026', true, true),
                          _buildStepDivider(),
                          _buildStep(context, Icons.check_circle_rounded, 'Payments Completed', 'Full amount received', true, false),
                          _buildStepDivider(),
                          _buildStep(context, Icons.radio_button_unchecked_rounded, 'Visa Processing', 'In progress with embassy', false, false),
                          _buildStepDivider(),
                          _buildStep(context, Icons.radio_button_unchecked_rounded, 'Flight Booking', 'Scheduled for next week', false, false),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Center(
                    child: TextButton.icon(
                      onPressed: () => context.pushNamed('MyJourney'),
                      icon: const Icon(Icons.assignment_rounded, size: 18),
                      label: const Text('View Full Journey Timeline'),
                      style: TextButton.styleFrom(foregroundColor: FlutterFlowTheme.of(context).primary),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(String label, String value, {bool isStatus = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(color: Colors.white.withValues(alpha: 0.6), fontSize: 11, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 6),
        if (isStatus)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFFD4AF37),
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  blurRadius: 4,
                )
              ],
            ),
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          )
        else
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 15,
            ),
          ),
      ],
    );
  }

  Widget _buildQuickAction(BuildContext context, IconData icon, String label, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: color.withValues(alpha: 0.2)),
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: -0.2),
          ),
        ],
      ),
    );
  }

  Widget _buildStep(BuildContext context, IconData icon, String title, String subtitle, bool isCompleted, bool isFirst) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            color: isCompleted ? FlutterFlowTheme.of(context).primary : Colors.grey[300],
            size: 24,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: isCompleted ? FlutterFlowTheme.of(context).primaryText : Colors.grey[600],
                    fontWeight: isCompleted ? FontWeight.bold : FontWeight.w500,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: FlutterFlowTheme.of(context).secondaryText,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          if (isCompleted)
            Icon(Icons.verified_rounded, color: FlutterFlowTheme.of(context).primary, size: 16),
        ],
      ),
    );
  }

  Widget _buildStepDivider() {
    return Container(
      margin: const EdgeInsets.only(left: 11, top: 2, bottom: 2),
      width: 2,
      height: 20,
      color: Colors.grey[100],
    );
  }
}
