import '../entities/home_dashboard_data.dart';

abstract class HomeDashboardRepository {
  Future<HomeDashboardData> getDashboardData(String userId);
  Future<void> saveSearchHistory(SearchHistoryEntity search);
  Future<void> saveRecentlyViewed(RecentlyViewedEntity item);
  Future<List<String>> getAiSuggestions(String query);
}
