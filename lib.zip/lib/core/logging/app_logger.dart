import 'package:flutter/foundation.dart';

class AppLogger {
  static void d(String message) {
    if (kDebugMode) {
      print('DEBUG: \$message');
    }
  }

  static void i(String message) {
    print('INFO: \$message');
  }

  static void e(String message, [dynamic error, StackTrace? stackTrace]) {
    print('ERROR: \$message');
    if (error != null) print('Error Details: \$error');
    if (stackTrace != null) print(stackTrace);
  }
}
