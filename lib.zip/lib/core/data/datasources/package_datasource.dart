import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../backend/schema/package_record.dart';

abstract class PackageDataSource {
  Future<List<PackageRecord>> fetchPackages();
}

class FirestorePackageDataSource implements PackageDataSource {
  final FirebaseFirestore _db;
  final bool useRealFirestore;

  FirestorePackageDataSource({
    FirebaseFirestore? db,
    this.useRealFirestore = true,
  }) : _db = db ?? FirebaseFirestore.instance;

  @override
  Future<List<PackageRecord>> fetchPackages() async {
    if (!useRealFirestore) return [];
    final snapshot = await _db.collection('packages').get();
    return snapshot.docs.map((doc) => PackageRecord.fromFirestore(doc)).toList();
  }
}
