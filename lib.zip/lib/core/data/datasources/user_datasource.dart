import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../backend/schema/users_record.dart';
import '../../../backend/schema/passenger_record.dart';
import '../../../backend/schema/reward_record.dart';

abstract class UserDataSource {
  Future<UsersRecord?> getUser(String uid);
  Future<void> createUser(UsersRecord user);
  Future<List<PassengerRecord>> fetchSavedPassengers(String userId);
  Future<void> savePassenger(PassengerRecord passenger);
  Future<void> addLoyaltyPoints(String userId, int points);
  Future<RewardRecord?> getRewards(String userId);
  Future<void> redeemPoints(String userId, int pointsToRedeem);
}

class FirestoreUserDataSource implements UserDataSource {
  final FirebaseFirestore _db;
  final bool useRealFirestore;

  FirestoreUserDataSource({
    FirebaseFirestore? db,
    this.useRealFirestore = true,
  }) : _db = db ?? FirebaseFirestore.instance;

  @override
  Future<UsersRecord?> getUser(String uid) async {
    if (!useRealFirestore) {
      return UsersRecord(
        uid: uid,
        email: 'test@example.com',
        displayName: 'Test User',
      );
    }
    final doc = await _db.collection('users').doc(uid).get();
    return doc.exists ? UsersRecord.fromFirestore(doc) : null;
  }

  @override
  Future<void> createUser(UsersRecord user) async {
    if (!useRealFirestore) return;
    await _db.collection('users').doc(user.uid).set(user.toMap());
  }

  @override
  Future<List<PassengerRecord>> fetchSavedPassengers(String userId) async {
    if (!useRealFirestore) return [];
    final snapshot = await _db.collection('saved_passengers')
        .where('userId', isEqualTo: userId)
        .get();
    return snapshot.docs.map((doc) => PassengerRecord.fromFirestore(doc)).toList();
  }

  @override
  Future<void> savePassenger(PassengerRecord passenger) async {
    if (!useRealFirestore) return;
    await _db.collection('saved_passengers').add(passenger.toMap());
  }

  @override
  Future<void> addLoyaltyPoints(String userId, int points) async {
    if (!useRealFirestore) return;
    await _db.collection('users').doc(userId).update({
      'loyaltyPoints': FieldValue.increment(points),
    });
  }

  @override
  Future<RewardRecord?> getRewards(String userId) async {
    if (!useRealFirestore) return RewardRecord(userId: userId, points: 250);
    final doc = await _db.collection('users').doc(userId).get();
    return RewardRecord(userId: userId, points: doc.data()?['loyaltyPoints'] ?? 0);
  }

  @override
  Future<void> redeemPoints(String userId, int pointsToRedeem) async {
    if (!useRealFirestore) return;
    await _db.collection('users').doc(userId).update({
      'loyaltyPoints': FieldValue.increment(-pointsToRedeem),
    });
  }
}
