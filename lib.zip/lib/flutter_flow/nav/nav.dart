import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '/auth/base_auth_user_provider.dart';

import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';

import '/index.dart';
import '../../pages/package_details/package_booking_widget.dart';
import '../../pages/car_rental/car_rental_details_widget.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      errorBuilder: (context, state) => appStateNotifier.loggedIn
          ? HomeDashboardWidget()
          : LoginOTPWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) => appStateNotifier.loggedIn
              ? HomeDashboardWidget()
              : LoginOTPWidget(),
        ),
        FFRoute(
          name: SplashOnboardingWidget.routeName,
          path: SplashOnboardingWidget.routePath,
          builder: (context, params) => SplashOnboardingWidget(),
        ),
        FFRoute(
          name: LoginOTPWidget.routeName,
          path: LoginOTPWidget.routePath,
          builder: (context, params) => LoginOTPWidget(),
        ),
        FFRoute(
          name: SignupWidget.routeName,
          path: SignupWidget.routePath,
          builder: (context, params) => SignupWidget(),
        ),
        FFRoute(
          name: HomeDashboardWidget.routeName,
          path: HomeDashboardWidget.routePath,
          builder: (context, params) => HomeDashboardWidget(),
        ),
        FFRoute(
          name: BusSearchResultsWidget.routeName,
          path: BusSearchResultsWidget.routePath,
          builder: (context, params) => BusSearchResultsWidget(
            fromLocation: params.getParam('fromLocation', ParamType.String),
            toLocation: params.getParam('toLocation', ParamType.String),
            date: params.getParam('date', ParamType.DateTime),
          ),
        ),
        FFRoute(
          name: HotelSearchResultsWidget.routeName,
          path: HotelSearchResultsWidget.routePath,
          builder: (context, params) => HotelSearchResultsWidget(
            destination: params.getParam('destination', ParamType.String),
            checkIn: params.getParam('checkIn', ParamType.DateTime),
            checkOut: params.getParam('checkOut', ParamType.DateTime),
            guests: params.getParam('guests', ParamType.int),
          ),
        ),
        FFRoute(
          name: HotelDetailsWidget.routeName,
          path: HotelDetailsWidget.routePath,
          builder: (context, params) {
            final hotel = params.getParam<dynamic>('hotel', ParamType.JSON);
            return HotelDetailsWidget(
              hotel: hotel is HotelRecord
                  ? hotel
                  : HotelRecord.fromMap(hotel, hotel['id'] ?? ''),
            );
          },
        ),
        FFRoute(
          name: HotelBookingConfirmationWidget.routeName,
          path: HotelBookingConfirmationWidget.routePath,
          builder: (context, params) {
            final hotel = params.getParam<dynamic>('hotel', ParamType.JSON);
            final room = params.getParam<dynamic>('room', ParamType.JSON);
            return HotelBookingConfirmationWidget(
              hotel: hotel is HotelRecord
                  ? hotel
                  : HotelRecord.fromMap(hotel, hotel['id'] ?? ''),
              room: room is RoomRecord
                  ? room
                  : RoomRecord.fromMap(room, room['id'] ?? ''),
            );
          },
        ),
        FFRoute(
          name: PackageListingWidget.routeName,
          path: PackageListingWidget.routePath,
          builder: (context, params) => const PackageListingWidget(),
        ),
        FFRoute(
          name: PackageBookingWidget.routeName,
          path: PackageBookingWidget.routePath,
          builder: (context, params) {
            final package = params.getParam<dynamic>('package', ParamType.JSON);
            return PackageBookingWidget(
              package: package is PackageRecord
                  ? package
                  : PackageRecord.fromMap(package, package['id'] ?? ''),
            );
          },
        ),
        FFRoute(
          name: PackageDetailsWidget.routeName,
          path: PackageDetailsWidget.routePath,
          builder: (context, params) {
            final package = params.getParam<dynamic>('package', ParamType.JSON);
            return PackageDetailsWidget(
              package: package is PackageRecord
                  ? package
                  : PackageRecord.fromMap(package, package['id'] ?? ''),
            );
          },
        ),
        FFRoute(
          name: TaxiBookingWidget.routeName,
          path: TaxiBookingWidget.routePath,
          builder: (context, params) => const TaxiBookingWidget(),
        ),
        FFRoute(
          name: CarRentalWidget.routeName,
          path: CarRentalWidget.routePath,
          builder: (context, params) => const CarRentalWidget(),
        ),
        FFRoute(
          name: CarRentalDetailsWidget.routeName,
          path: CarRentalDetailsWidget.routePath,
          builder: (context, params) {
            final car = params.getParam<dynamic>('car', ParamType.JSON);
            return CarRentalDetailsWidget(
              car: car is RentalRecord
                  ? car
                  : RentalRecord.fromMap(car, car['id'] ?? ''),
            );
          },
        ),
        FFRoute(
          name: ReferralWidget.routeName,
          path: ReferralWidget.routePath,
          builder: (context, params) => const ReferralWidget(),
        ),
        FFRoute(
          name: SeatSelectionWidget.routeName,
          path: SeatSelectionWidget.routePath,
          builder: (context, params) {
            final busMap = params.getParam<Map<String, dynamic>>('bus', ParamType.JSON);
            return SeatSelectionWidget(
              bus: busMap != null ? BusRecord.fromMap(busMap, busMap['id'] ?? '') : null,
            );
          },
        ),
        FFRoute(
          name: PassengerDetailsWidget.routeName,
          path: PassengerDetailsWidget.routePath,
          builder: (context, params) {
            final busMap = params.getParam<Map<String, dynamic>>('bus', ParamType.JSON);
            return PassengerDetailsWidget(
              selectedSeats: params.getParam<String>(
                'selectedSeats',
                ParamType.String,
                isList: true,
              ),
              bus: busMap != null ? BusRecord.fromMap(busMap, busMap['id'] ?? '') : null,
            );
          },
        ),
        FFRoute(
          name: PaymentCheckoutWidget.routeName,
          path: PaymentCheckoutWidget.routePath,
          builder: (context, params) {
            final bookingMap = params.getParam<Map<String, dynamic>>('booking', ParamType.JSON);
            return PaymentCheckoutWidget(
              booking: bookingMap != null ? BookingRecord.fromMap(bookingMap) : null,
            );
          },
        ),
        FFRoute(
          name: BookingConfirmationTicketWidget.routeName,
          path: BookingConfirmationTicketWidget.routePath,
          builder: (context, params) {
            final bookingMap = params.getParam<Map<String, dynamic>>('booking', ParamType.JSON);
            return BookingConfirmationTicketWidget(
              booking: bookingMap != null ? BookingRecord.fromMap(bookingMap) : null,
            );
          },
        ),
        FFRoute(
          name: MyTripsWidget.routeName,
          path: MyTripsWidget.routePath,
          builder: (context, params) => MyTripsWidget(),
        ),
        FFRoute(
          name: ProfileSettingsWidget.routeName,
          path: ProfileSettingsWidget.routePath,
          builder: (context, params) => const ProfileSettingsWidget(),
        ),
        FFRoute(
          name: PersonalInfoWidget.routeName,
          path: PersonalInfoWidget.routePath,
          builder: (context, params) => const PersonalInfoWidget(),
        ),
        FFRoute(
          name: WalletWidget.routeName,
          path: WalletWidget.routePath,
          builder: (context, params) => const WalletWidget(),
        ),
        FFRoute(
          name: NotificationsWidget.routeName,
          path: NotificationsWidget.routePath,
          builder: (context, params) => const NotificationsWidget(),
        ),
        FFRoute(
          name: LiveTrackingWidget.routeName,
          path: LiveTrackingWidget.routePath,
          builder: (context, params) => LiveTrackingWidget(
            busId: params.getParam<String>('busId', ParamType.String),
          ),
        ),
        FFRoute(
          name: AllRoutesWidget.routeName,
          path: AllRoutesWidget.routePath,
          builder: (context, params) => const AllRoutesWidget(),
        ),
        FFRoute(
          name: 'HajjDashboard',
          path: '/hajjDashboard',
          builder: (context, params) => const HajjDashboardScreen(),
        ),
        FFRoute(
          name: 'HajjPackages',
          path: '/hajjPackages',
          builder: (context, params) {
            final typeStr = params.getParam<String>('type', ParamType.String);
            return PackageListingScreen(
              type: PackageType.values.firstWhere(
                (e) => e.name == typeStr,
                orElse: () => PackageType.hajj,
              ),
            );
          },
        ),
        FFRoute(
          name: 'HajjPackageDetails',
          path: '/hajjPackageDetails',
          builder: (context, params) => PackageDetailsScreen(
            packageId: params.getParam<String>('id', ParamType.String)!,
          ),
        ),
        FFRoute(
          name: 'HajjBooking',
          path: '/hajjBooking',
          builder: (context, params) => HajjBookingScreen(
            package: params.getParam<HajjPackage>('package', ParamType.JSON),
          ),
        ),
        FFRoute(
          name: 'MyJourney',
          path: '/myJourney',
          builder: (context, params) => const MyJourneyScreen(),
        ),
        FFRoute(
          name: 'IslamicTools',
          path: '/islamicTools',
          builder: (context, params) => IslamicToolsScreen(
            initialTab: params.getParam<int>('initialTab', ParamType.int) ?? 0,
          ),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return '/loginOTP';
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Center(
                  child: SizedBox(
                    width: 50.0,
                    height: 50.0,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                        FlutterFlowTheme.of(context).primary,
                      ),
                    ),
                  ),
                )
              : page;

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  name: state.name,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(
                  key: state.pageKey, name: state.name, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => const TransitionInfo(
        hasTransition: true,
        transitionType: PageTransitionType.fade,
        duration: Duration(milliseconds: 300),
      );
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
