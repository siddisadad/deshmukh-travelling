import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';

class PackageBookingModel extends FlutterFlowModel {
  int travelerCount = 1;
  DateTime? selectedDate;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
