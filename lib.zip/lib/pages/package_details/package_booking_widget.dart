import '/components/app_header.dart';
import '/components/button/button_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '../../backend/schema/package_record.dart';
import '../payment_checkout/payment_checkout_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package_booking_model.dart';

class PackageBookingWidget extends StatefulWidget {
  final PackageRecord package;

  const PackageBookingWidget({super.key, required this.package});

  static String routeName = 'PackageBooking';
  static String routePath = '/packageBooking';

  @override
  State<PackageBookingWidget> createState() => _PackageBookingWidgetState();
}

class _PackageBookingWidgetState extends State<PackageBookingWidget> {
  late PackageBookingModel _model;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PackageBookingModel());
    _model.selectedDate = DateTime.now().add(const Duration(days: 14));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      body: Column(
        children: [
          const AppHeader(title: 'Book Holiday'),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.package.title,
                    style: FlutterFlowTheme.of(context).titleLarge.override(
                          font: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.bold),
                        ),
                  ),
                  const SizedBox(height: 24),
                  Text('Select Departure Date', style: FlutterFlowTheme.of(context).bodyMedium.override(font: GoogleFonts.inter(fontWeight: FontWeight.bold))),
                  const SizedBox(height: 12),
                  InkWell(
                    onTap: () async {
                      final date = await showDatePicker(
                        context: context,
                        initialDate: _model.selectedDate!,
                        firstDate: DateTime.now(),
                        lastDate: DateTime.now().add(const Duration(days: 365)),
                      );
                      if (date != null) setState(() => _model.selectedDate = date);
                    },
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: FlutterFlowTheme.of(context).alternate),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.calendar_today_rounded, color: FlutterFlowTheme.of(context).primary, size: 20),
                          const SizedBox(width: 12),
                          Text(DateFormat('dd MMM, yyyy').format(_model.selectedDate!), style: FlutterFlowTheme.of(context).bodyMedium),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),
                  Text('Number of Travelers', style: FlutterFlowTheme.of(context).bodyMedium.override(font: GoogleFonts.inter(fontWeight: FontWeight.bold))),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _counterButton(Icons.remove, () {
                        if (_model.travelerCount > 1) setState(() => _model.travelerCount--);
                      }),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Text(_model.travelerCount.toString(), style: FlutterFlowTheme.of(context).titleLarge),
                      ),
                      _counterButton(Icons.add, () {
                        setState(() => _model.travelerCount++);
                      }),
                    ],
                  ),
                  const SizedBox(height: 40),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).primaryContainer.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: FlutterFlowTheme.of(context).primary.withValues(alpha: 0.2)),
                    ),
                    child: Column(
                      children: [
                        _priceRow('Package Price', '₹${widget.package.price.toInt()}'),
                        const SizedBox(height: 8),
                        _priceRow('Travelers', 'x${_model.travelerCount}'),
                        const Divider(height: 24),
                        _priceRow('Total Amount', '₹${(widget.package.price * _model.travelerCount).toInt()}', isTotal: true),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          boxShadow: [BoxShadow(blurRadius: 10, color: const Color(0x1A000000), offset: const Offset(0, -4))],
        ),
        child: ButtonWidget(
          content: 'Proceed to Payment',
          variant: 'primary',
          size: 'large',
          onTap: () {
            context.pushNamed(PaymentCheckoutWidget.routeName);
          },
        ),
      ),
    );
  }

  Widget _counterButton(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          border: Border.all(color: FlutterFlowTheme.of(context).primary),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: FlutterFlowTheme.of(context).primary, size: 20),
      ),
    );
  }

  Widget _priceRow(String label, String value, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: isTotal ? FlutterFlowTheme.of(context).bodyLarge.override(font: GoogleFonts.inter(fontWeight: FontWeight.bold)) : FlutterFlowTheme.of(context).bodyMedium),
        Text(value, style: isTotal ? FlutterFlowTheme.of(context).titleLarge.override(font: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.bold), color: FlutterFlowTheme.of(context).primary) : FlutterFlowTheme.of(context).bodyLarge),
      ],
    );
  }
}
