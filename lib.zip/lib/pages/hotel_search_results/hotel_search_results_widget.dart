import '../hotel_details/hotel_details_widget.dart';
import '/components/hotel_card/hotel_card_widget.dart';
import '/components/app_header.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'hotel_search_results_model.dart';
export 'hotel_search_results_model.dart';

class HotelSearchResultsWidget extends StatefulWidget {
  final String? destination;
  final DateTime? checkIn;
  final DateTime? checkOut;
  final int? guests;

  const HotelSearchResultsWidget({
    super.key,
    this.destination,
    this.checkIn,
    this.checkOut,
    this.guests,
  });

  static String routeName = 'HotelSearchResults';
  static String routePath = '/hotelSearchResults';

  @override
  State<HotelSearchResultsWidget> createState() => _HotelSearchResultsWidgetState();
}

class _HotelSearchResultsWidgetState extends State<HotelSearchResultsWidget> {
  late HotelSearchResultsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HotelSearchResultsModel());
    _model.fetchHotels(widget.destination ?? 'Mumbai').then((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: Column(
          children: [
            AppHeader(
              title: widget.destination ?? 'Hotels',
              bottom: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 12.0),
                    child: Row(
                      children: [
                        Icon(Icons.calendar_today_rounded, size: 14, color: FlutterFlowTheme.of(context).secondaryText),
                        const SizedBox(width: 6),
                        Text(
                          '${dateTimeFormat('d MMM', widget.checkIn)} - ${dateTimeFormat('d MMM', widget.checkOut)} • ${widget.guests} Guests',
                          style: FlutterFlowTheme.of(context).bodySmall,
                        ),
                      ],
                    ),
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Padding(
                      padding: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 16.0),
                      child: Row(
                        children: [
                          _filterChip(
                            'Rating 4+',
                            Icons.star_rounded,
                            _model.rating4Plus,
                            () => setState(() {
                              _model.rating4Plus = !_model.rating4Plus;
                              _model.applyFilters();
                            }),
                          ),
                          const SizedBox(width: 8),
                          _filterChip(
                            'Price',
                            Icons.currency_rupee_rounded,
                            _model.priceSort != null,
                            () async {
                              final res = await showModalBottomSheet<String>(
                                context: context,
                                builder: (context) => Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    ListTile(title: const Text('Price: Low to High'), onTap: () => Navigator.pop(context, 'asc')),
                                    ListTile(title: const Text('Price: High to Low'), onTap: () => Navigator.pop(context, 'desc')),
                                    ListTile(title: const Text('Clear Sort'), onTap: () => Navigator.pop(context, 'clear')),
                                  ],
                                ),
                              );
                              if (res != null) {
                                setState(() {
                                  _model.priceSort = res == 'clear' ? null : res;
                                  _model.applyFilters();
                                });
                              }
                            },
                          ),
                          const SizedBox(width: 8),
                          _filterChip(
                            'Free WiFi',
                            Icons.wifi_rounded,
                            _model.freeWifi,
                            () => setState(() {
                              _model.freeWifi = !_model.freeWifi;
                              _model.applyFilters();
                            }),
                          ),
                          const SizedBox(width: 8),
                          _filterChip(
                            'Pool',
                            Icons.pool_rounded,
                            _model.pool,
                            () => setState(() {
                              _model.pool = !_model.pool;
                              _model.applyFilters();
                            }),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SafeArea(
                top: false,
                child: _model.isLoading
                    ? Center(
                        child: CircularProgressIndicator(
                          color: FlutterFlowTheme.of(context).primary,
                        ),
                      )
                    : Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: ListView.separated(
                          itemCount: _model.hotels.length,
                          separatorBuilder: (context, index) => const SizedBox(height: 16),
                          itemBuilder: (context, index) {
                            final hotel = _model.hotels[index];
                            return HotelCardWidget(
                              name: hotel.name,
                              location: hotel.location,
                              rating: hotel.rating,
                              reviewsCount: hotel.reviewsCount,
                              image: hotel.images.first,
                              price: hotel.startingPrice,
                              onTap: () {
                                context.pushNamed(
                                  HotelDetailsWidget.routeName,
                                  extra: <String, dynamic>{
                                    'hotel': hotel,
                                  },
                                );
                              },
                            );
                          },
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filterChip(String label, IconData icon, bool isSelected, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? FlutterFlowTheme.of(context).primary : FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? FlutterFlowTheme.of(context).primary : FlutterFlowTheme.of(context).alternate,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 14,
              color: isSelected ? Colors.white : FlutterFlowTheme.of(context).secondaryText,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: FlutterFlowTheme.of(context).labelSmall.override(
                    font: GoogleFonts.inter(),
                    color: isSelected ? Colors.white : FlutterFlowTheme.of(context).primaryText,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
