import '/flutter_flow/flutter_flow_util.dart';
import '../../backend/schema/hotel_record.dart';
import '../../backend/firebase/firestore_service.dart';
import 'hotel_search_results_widget.dart' show HotelSearchResultsWidget;
import 'package:flutter/material.dart';

class HotelSearchResultsModel extends FlutterFlowModel<HotelSearchResultsWidget> {
  ///  State fields for stateful widgets in this page.

  final firestoreService = FirestoreService();
  List<HotelRecord> allHotels = [];
  List<HotelRecord> hotels = [];
  bool isLoading = true;

  bool rating4Plus = false;
  bool freeWifi = false;
  bool pool = false;
  String? priceSort; // 'asc', 'desc'

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  Future<void> fetchHotels(String city) async {
    isLoading = true;
    allHotels = await firestoreService.fetchHotels(city);
    applyFilters();
    isLoading = false;
  }

  void applyFilters() {
    hotels = allHotels.where((h) {
      if (rating4Plus && h.rating < 4.0) return false;
      // Add other filter logic here if amenities are in schema
      return true;
    }).toList();

    if (priceSort == 'asc') {
      hotels.sort((a, b) => a.startingPrice.compareTo(b.startingPrice));
    } else if (priceSort == 'desc') {
      hotels.sort((a, b) => b.startingPrice.compareTo(a.startingPrice));
    }
  }
}
