import '../bus_search_results/bus_search_results_widget.dart';
import '../hotel_search_results/hotel_search_results_widget.dart';
import '../ai_assistant/ai_assistant_widget.dart';
import '../notifications/notifications_widget.dart';
import '../taxi_booking/taxi_booking_widget.dart';
import '../package_listing/package_listing_widget.dart';
import '../car_rental/car_rental_widget.dart';
import 'components/search_form.dart';
import 'components/wallet_summary.dart';
import 'components/ai_assistant_fab.dart';
import 'components/ai_search_suggestions.dart';
import '/components/button/button_widget.dart';
import 'package:flutter/material.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../l10n/app_localizations.dart';
import 'home_dashboard_model.dart';
import '../../components/home_header.dart';
import '../../components/app_nav_bar.dart';

export 'home_dashboard_model.dart';

class HomeDashboardWidget extends StatefulWidget {
  const HomeDashboardWidget({super.key});

  static const String routeName = 'HomeDashboard';
  static const String routePath = '/homeDashboard';

  @override
  State<HomeDashboardWidget> createState() => _HomeDashboardWidgetState();
}

class _HomeDashboardWidgetState extends State<HomeDashboardWidget> {
  late HomeDashboardModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomeDashboardModel());
    _model.loadRecentSearches().then((_) => safeSetState(() {}));
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  Future<void> _showLocationPicker(bool isFrom) async {
    final selectedCity = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final List<String> filteredCities = _model.popularCities
                .where((city) => city
                    .toLowerCase()
                    .contains(_model.citySearchText.toLowerCase()))
                .toList();

            return Container(
              height: MediaQuery.of(context).size.height * 0.7,
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(24.0),
                  topRight: Radius.circular(24.0),
                ),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Container(
                      width: 40.0,
                      height: 4.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).alternate,
                        borderRadius: BorderRadius.circular(2.0),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24.0, vertical: 8.0),
                    child: Text(
                      isFrom
                          ? AppLocalizations.of(context)!.selectOrigin
                          : AppLocalizations.of(context)!.selectDestination,
                      style: FlutterFlowTheme.of(context).titleMedium,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: TextField(
                      autofocus: true,
                      decoration: InputDecoration(
                        hintText: AppLocalizations.of(context)!.searchCity,
                        prefixIcon: const Icon(Icons.search),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        contentPadding: const EdgeInsets.symmetric(vertical: 0),
                      ),
                      onChanged: (value) {
                        setModalState(() {
                          _model.citySearchText = value;
                        });
                        _model.updateAiSuggestions(value);
                      },
                    ),
                  ),
                  Expanded(
                    child: filteredCities.isEmpty
                        ? Center(
                            child: Text(
                              'No cities found',
                              style: FlutterFlowTheme.of(context).bodyMedium,
                            ),
                          )
                        : ListView.builder(
                            itemCount: filteredCities.length,
                            itemBuilder: (context, index) {
                              final city = filteredCities[index];
                              return ListTile(
                                title: Text(city),
                                leading: const Icon(Icons.location_on_outlined),
                                onTap: () => Navigator.pop(context, city),
                              );
                            },
                          ),
                  ),
                ],
              ),
            );
          },
        );
      },
    ).then((value) {
      _model.citySearchText = '';
      return value;
    });

    if (selectedCity != null) {
      safeSetState(() {
        if (_model.selectedService == 'Hotel') {
          _model.hotelLocation = selectedCity;
        } else {
          if (isFrom) {
            _model.fromLocation = selectedCity;
          } else {
            _model.toLocation = selectedCity;
          }
        }
      });
    }
  }

  Future<void> _showPassengerPicker() async {
    final count = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(24.0),
              topRight: Radius.circular(24.0),
            ),
          ),
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Select Passengers',
                style: FlutterFlowTheme.of(context).titleLarge,
              ),
              const SizedBox(height: 24.0),
              StatefulBuilder(
                builder: (context, setModalState) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FlutterFlowIconButton(
                        borderRadius: 20.0,
                        buttonSize: 44.0,
                        fillColor: FlutterFlowTheme.of(context).alternate,
                        icon: Icon(
                          Icons.remove,
                          color: FlutterFlowTheme.of(context).primaryText,
                          size: 24.0,
                        ),
                        onPressed: _model.passengerCount > 1
                            ? () => setModalState(() => _model.passengerCount--)
                            : null,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 32.0),
                        child: Text(
                          _model.passengerCount.toString(),
                          style: FlutterFlowTheme.of(context).displaySmall,
                        ),
                      ),
                      FlutterFlowIconButton(
                        borderRadius: 20.0,
                        buttonSize: 44.0,
                        fillColor: FlutterFlowTheme.of(context).alternate,
                        icon: Icon(
                          Icons.add,
                          color: FlutterFlowTheme.of(context).primaryText,
                          size: 24.0,
                        ),
                        onPressed: _model.passengerCount < 10
                            ? () => setModalState(() => _model.passengerCount++)
                            : null,
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 32.0),
              ButtonWidget(
                content: 'Done',
                variant: 'primary',
                size: 'large',
                fullWidth: true,
                onTap: () => Navigator.pop(context, _model.passengerCount),
              ),
            ],
          ),
        );
      },
    );
    if (count != null) safeSetState(() {});
  }

  Widget _serviceItem(String label, IconData icon) {
    bool isSelected = _model.selectedService == label;
    return InkWell(
      onTap: () {
        setState(() {
          _model.selectedService = label;
        });
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: isSelected
                  ? FlutterFlowTheme.of(context).secondary
                  : FlutterFlowTheme.of(context).onPrimary10,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              icon,
              color: isSelected
                  ? FlutterFlowTheme.of(context).onSurface
                  : FlutterFlowTheme.of(context).onPrimary,
              size: 28,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: FlutterFlowTheme.of(context).labelSmall.override(
                  font: GoogleFonts.inter(),
                  color: isSelected
                      ? FlutterFlowTheme.of(context).onPrimary
                      : FlutterFlowTheme.of(context).onPrimary80,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        bottomNavigationBar: const AppNavBar(currentRoute: HomeDashboardWidget.routeName),
        floatingActionButton: AiAssistantFab(
          onTap: () => context.pushNamed(AiAssistantWidget.routeName),
        ),
        body: SingleChildScrollView(
          primary: true,
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              HomeHeader(
                appTitle: AppLocalizations.of(context)!.appTitle,
                subtitle: 'Explore the world with ease',
                onNotificationTap: () => context.pushNamed(NotificationsWidget.routeName),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _serviceItem('Bus', Icons.directions_bus_rounded),
                          _serviceItem('Hotel', Icons.hotel_rounded),
                          _serviceItem('Taxi', Icons.local_taxi_rounded),
                          _serviceItem('Hajj', Icons.mosque_rounded),
                          _serviceItem('Holiday', Icons.beach_access_rounded),
                          _serviceItem('Rentals', Icons.car_rental_rounded),
                        ].divide(const SizedBox(width: 12.0)),
                      ),
                    ),
                    const SizedBox(height: 16.0),
                    SearchForm(
                      model: _model,
                      onSwap: () => setState(() => _model.swapLocations()),
                      onPickLocation: (isFrom) => _showLocationPicker(isFrom),
                      onPickDate: () async {
                        if (_model.selectedService == 'Hotel') {
                          final dateRange = await showDateRangePicker(
                            context: context,
                            firstDate: DateTime.now(),
                            lastDate: DateTime(2050),
                          );
                          if (dateRange != null) {
                            safeSetState(() {
                              _model.checkInDate = dateRange.start;
                              _model.checkOutDate = dateRange.end;
                            });
                          }
                        } else {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: _model.selectedDate ?? DateTime.now(),
                            firstDate: DateTime.now(),
                            lastDate: DateTime(2050),
                          );
                          if (date != null) safeSetState(() => _model.selectedDate = date);
                        }
                      },
                      onPickPassengers: () => _model.selectedService == 'Hotel' ? null : _showPassengerPicker(),
                      onSearch: () async {
                        if (_model.selectedService == 'Hotel') {
                           context.pushNamed(HotelSearchResultsWidget.routeName);
                        } else if (_model.selectedService == 'Hajj') {
                           context.pushNamed('HajjDashboard');
                        } else if (_model.selectedService == 'Taxi') {
                           context.pushNamed(TaxiBookingWidget.routeName);
                        } else if (_model.selectedService == 'Holiday') {
                           context.pushNamed(PackageListingWidget.routeName);
                        } else if (_model.selectedService == 'Rentals') {
                           context.pushNamed(CarRentalWidget.routeName);
                        } else {
                           context.pushNamed(BusSearchResultsWidget.routeName);
                        }
                      },
                    ),
                    AiSearchSuggestions(
                      suggestions: _model.aiSuggestions,
                      onSelected: (val) => setState(() => _model.aiSuggestions = []),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    if (_model.recentSearches.isNotEmpty) ...[
                      Text(AppLocalizations.of(context)!.recentSearches, style: FlutterFlowTheme.of(context).labelMedium),
                      const SizedBox(height: 8),
                      // ... Recent Searches List ...
                    ],
                    const SizedBox(height: 16),
                    WalletSummary(
                      balance: _model.walletBalance,
                      rewardPoints: _model.rewardPoints,
                      onTap: () => context.pushNamed('Wallet'),
                    ),
                  ],
                ),
              ),
              // Additional Content (Popular Routes, etc.)
            ],
          ),
        ),
      ),
    );
  }
}
