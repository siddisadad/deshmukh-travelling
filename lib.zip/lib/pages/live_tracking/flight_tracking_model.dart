import '/flutter_flow/flutter_flow_util.dart' hide LatLng;
import '../../backend/firebase/firestore_service.dart';
import 'flight_tracking_widget.dart' show FlightTrackingWidget;
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:async';
import 'dart:math' show cos, sqrt, asin;

class FlightTrackingModel extends FlutterFlowModel<FlightTrackingWidget> {
  final firestoreService = FirestoreService();
  GoogleMapController? googleMapController;
  Set<Marker> markers = {};
  Set<Polyline> polylines = {};

  StreamSubscription<Map<String, dynamic>>? flightSubscription;
  double currentLat = 19.0760;
  double currentLng = 72.8777;
  String flightNumber = 'AI-101';
  String status = 'On Time';
  String eta = '45 Mins';
  String gate = 'T2 - G12';

  // Destination (e.g. London Heathrow)
  final LatLng destination = LatLng(51.4700, -0.4543);

  // Weather info
  String weatherTemp = '18°C';
  String weatherCondition = 'Clear Sky';
  IconData weatherIcon = Icons.wb_sunny_rounded;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    flightSubscription?.cancel();
  }

  void updateFlightEta() {
    double p = 0.017453292519943295;
    final c = cos;
    double a = 0.5 - c((destination.latitude - currentLat) * p) / 2 +
        c(currentLat * p) * c(destination.latitude * p) *
            (1 - c((destination.longitude - currentLng) * p)) / 2;
    double dist = 12742 * asin(sqrt(a));

    // Mock ETA for flight: 1 minute per 15km (very fast)
    eta = '${(dist / 15).toInt()} Mins';
  }
}
