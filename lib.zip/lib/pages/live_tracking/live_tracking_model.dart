import '/flutter_flow/flutter_flow_util.dart' hide LatLng;
import '../../backend/firebase/firestore_service.dart';
import 'live_tracking_widget.dart' show LiveTrackingWidget;
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:async';
import 'dart:math' show cos, sqrt, asin;

class LiveTrackingModel extends FlutterFlowModel<LiveTrackingWidget> {
  ///  State fields for stateful widgets in this page.
  final firestoreService = FirestoreService();
  GoogleMapController? googleMapController;
  Set<Marker> markers = {};
  Set<Polyline> polylines = {};

  StreamSubscription<Map<String, double>>? locationSubscription;
  double currentLat = 19.1000;
  double currentLng = 72.8800;
  String eta = '15 Mins';
  String distance = '4.2 km';

  // Driver details
  String driverName = 'Suresh Patil';
  String driverPhone = '+919876543210';
  String busNumber = 'MH-12-AS-1234';

  // Mock destination for ETA calculation
  final LatLng destination = LatLng(19.2000, 72.9500);

  // Weather info
  String weatherTemp = '28°C';
  String weatherCondition = 'Partly Cloudy';
  IconData weatherIcon = Icons.cloud_queue_rounded;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    locationSubscription?.cancel();
  }

  void updateEtaAndDistance() {
    double p = 0.017453292519943295;
    final c = cos;
    double a = 0.5 - c((destination.latitude - currentLat) * p) / 2 +
        c(currentLat * p) * c(destination.latitude * p) *
            (1 - c((destination.longitude - currentLng) * p)) / 2;
    double dist = 12742 * asin(sqrt(a));

    distance = '${dist.toStringAsFixed(1)} km';
    // Mock ETA: 3 minutes per km
    eta = '${(dist * 3).toInt()} Mins';
  }
}
