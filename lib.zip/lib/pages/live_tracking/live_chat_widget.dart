import 'package:flutter/material.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/components/app_header.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import 'live_chat_model.dart';
export 'live_chat_model.dart';

class LiveChatWidget extends StatefulWidget {
  const LiveChatWidget({super.key});

  static String routeName = 'LiveChat';
  static String routePath = '/liveChat';

  @override
  State<LiveChatWidget> createState() => _LiveChatWidgetState();
}

class _LiveChatWidgetState extends State<LiveChatWidget> {
  late LiveChatModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LiveChatModel());
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  void _sendMessage() {
    if (_model.textController?.text.isNotEmpty ?? false) {
      setState(() {
        _model.addMessage(_model.textController!.text, true);
        _model.textController?.clear();
      });

      // Simulated Driver response
      Future.delayed(Duration(seconds: 1), () {
        if (mounted) {
          setState(() {
            _model.addMessage("Understood, I'll take care of that.", false);
          });
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      body: Column(
        children: [
          AppHeader(
            title: 'Suresh Patil',
            bottom: Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 16.0),
              child: Row(
                children: [
                  Icon(Icons.directions_bus_rounded, size: 14, color: FlutterFlowTheme.of(context).secondaryText),
                  const SizedBox(width: 8),
                  Text(
                    'Bus Captain • MH-12-AS-1234',
                    style: FlutterFlowTheme.of(context).bodySmall,
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: SafeArea(
              top: false,
              child: Column(
                children: [
                  Expanded(
                    child: ListView.builder(
                      padding: const EdgeInsets.all(16.0),
                      reverse: true,
                      itemCount: _model.messages.length,
                      itemBuilder: (context, index) {
                        final message = _model.messages[_model.messages.length - 1 - index];
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4.0),
                          child: Row(
                            mainAxisAlignment: message.isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
                            children: [
                              Container(
                                constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
                                padding: const EdgeInsets.all(12.0),
                                decoration: BoxDecoration(
                                  color: message.isMe ? FlutterFlowTheme.of(context).primary : FlutterFlowTheme.of(context).secondaryBackground,
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                child: Text(
                                  message.text,
                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Outfit',
                                    color: message.isMe ? Colors.white : FlutterFlowTheme.of(context).primaryText,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(12.0),
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                    child: Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: _model.textController,
                            focusNode: _model.textFieldFocusNode,
                            decoration: InputDecoration(
                              hintText: 'Type a message...',
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24.0), borderSide: BorderSide.none),
                              filled: true,
                              fillColor: FlutterFlowTheme.of(context).primaryBackground,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 20.0),
                            ),
                            onFieldSubmitted: (_) => _sendMessage(),
                          ),
                        ),
                        const SizedBox(width: 8.0),
                        FlutterFlowIconButton(
                          borderColor: Colors.transparent,
                          borderRadius: 30.0,
                          buttonSize: 48.0,
                          fillColor: FlutterFlowTheme.of(context).primary,
                          icon: const Icon(Icons.send_rounded, color: Colors.white, size: 24.0),
                          onPressed: _sendMessage,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
