import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as google_maps;
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/components/app_header.dart';
import 'flight_tracking_model.dart';
export 'flight_tracking_model.dart';

class FlightTrackingWidget extends StatefulWidget {
  const FlightTrackingWidget({
    super.key,
    this.flightId,
  });

  final String? flightId;

  static String routeName = 'FlightTracking';
  static String routePath = '/flightTracking';

  @override
  State<FlightTrackingWidget> createState() => _FlightTrackingWidgetState();
}

class _FlightTrackingWidgetState extends State<FlightTrackingWidget> {
  late FlightTrackingModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  static const google_maps.LatLng _initialPosition = google_maps.LatLng(19.0760, 72.8777);

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FlightTrackingModel());

    _model.flightSubscription = _model.firestoreService
        .getFlightStatusStream(widget.flightId ?? 'flight1')
        .listen((data) {
      if (!mounted) return;
      setState(() {
        _model.currentLat = data['lat'] ?? _model.currentLat;
        _model.currentLng = data['lng'] ?? _model.currentLng;
        _model.status = data['status'] ?? 'On Time';
        _model.updateFlightEta();
        _model.gate = data['gate'] ?? '--';

        _model.markers.clear();
        _model.markers.add(
          google_maps.Marker(
            markerId: const google_maps.MarkerId('flight_marker'),
            position: google_maps.LatLng(_model.currentLat, _model.currentLng),
            icon: google_maps.BitmapDescriptor.defaultMarkerWithHue(
                google_maps.BitmapDescriptor.hueCyan),
            rotation: 45.0,
          ),
        );
      });

      _model.googleMapController?.animateCamera(
        google_maps.CameraUpdate.newCameraPosition(
          google_maps.CameraPosition(
            target: google_maps.LatLng(_model.currentLat, _model.currentLng),
            zoom: 8.0,
            tilt: 45.0,
          ),
        ),
      );
    });
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      body: Column(
        children: [
          const AppHeader(title: 'Flight Tracking'),
          Expanded(
            child: Stack(
              children: [
                google_maps.GoogleMap(
                  initialCameraPosition: const google_maps.CameraPosition(target: _initialPosition, zoom: 10.0),
                  markers: _model.markers,
                  onMapCreated: (controller) => _model.googleMapController = controller,
                  myLocationEnabled: true,
                  trafficEnabled: true,
                ),
                Positioned(
                  bottom: 24.0,
                  left: 24.0,
                  right: 24.0,
                  child: Container(
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                      borderRadius: BorderRadius.circular(16.0),
                      boxShadow: [BoxShadow(blurRadius: 10.0, color: const Color(0x33000000), offset: const Offset(0.0, 5.0))],
                    ),
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.flight_takeoff_rounded, color: FlutterFlowTheme.of(context).primary, size: 32),
                            const SizedBox(width: 16.0),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(_model.flightNumber, style: FlutterFlowTheme.of(context).titleMedium),
                                  Text('Air India • Economy', style: FlutterFlowTheme.of(context).labelSmall),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6.0),
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context).success.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                              child: Text(_model.status, style: TextStyle(color: FlutterFlowTheme.of(context).success, fontSize: 12.0, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                        const Divider(height: 32.0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('ETA', style: FlutterFlowTheme.of(context).labelSmall),
                                Text(_model.eta, style: FlutterFlowTheme.of(context).titleSmall),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text('Gate', style: FlutterFlowTheme.of(context).labelSmall),
                                Text(_model.gate, style: FlutterFlowTheme.of(context).titleSmall),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text('Terminal', style: FlutterFlowTheme.of(context).labelSmall),
                                Text('2', style: FlutterFlowTheme.of(context).titleSmall),
                              ],
                            ),
                          ],
                        ),
                        const Divider(height: 32.0),
                        Row(
                          children: [
                            Icon(_model.weatherIcon, color: FlutterFlowTheme.of(context).secondaryText, size: 24),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Arrival Weather', style: FlutterFlowTheme.of(context).labelSmall),
                                Text('${_model.weatherTemp} • ${_model.weatherCondition}', style: FlutterFlowTheme.of(context).bodyMedium),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
