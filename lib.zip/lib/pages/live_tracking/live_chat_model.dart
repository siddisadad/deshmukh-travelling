import '/flutter_flow/flutter_flow_util.dart';
import 'live_chat_widget.dart' show LiveChatWidget;
import 'package:flutter/material.dart';

class ChatMessage {
  final String text;
  final bool isMe;
  final DateTime timestamp;

  ChatMessage({required this.text, required this.isMe, required this.timestamp});
}

class LiveChatModel extends FlutterFlowModel<LiveChatWidget> {
  final List<ChatMessage> messages = [];
  TextEditingController? textController;
  FocusNode? textFieldFocusNode;

  @override
  void initState(BuildContext context) {
    textController = TextEditingController();
    textFieldFocusNode = FocusNode();

    // Initial message from Driver
    messages.add(ChatMessage(
      text: "Hello! I am your captain today. Let me know if you need any assistance.",
      isMe: false,
      timestamp: DateTime.now().subtract(Duration(minutes: 5)),
    ));
  }

  @override
  void dispose() {
    textController?.dispose();
    textFieldFocusNode?.dispose();
  }

  void addMessage(String text, bool isMe) {
    messages.add(ChatMessage(text: text, isMe: isMe, timestamp: DateTime.now()));
  }
}
