import 'package:cloud_firestore/cloud_firestore.dart';

class UsersRecord {
  final String? email;
  final String? displayName;
  final String? photoUrl;
  final String? uid;
  final DateTime? createdTime;
  final String? phoneNumber;
  final DateTime? dob;

  UsersRecord({
    this.email,
    this.displayName,
    this.photoUrl,
    this.uid,
    this.createdTime,
    this.phoneNumber,
    this.dob,
  });

  static UsersRecord fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UsersRecord(
      email: data['email'] as String?,
      displayName: data['display_name'] as String?,
      photoUrl: data['photo_url'] as String?,
      uid: data['uid'] as String?,
      createdTime: (data['created_time'] as Timestamp?)?.toDate(),
      phoneNumber: data['phone_number'] as String?,
      dob: (data['dob'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'dob': dob,
    };
  }
}
